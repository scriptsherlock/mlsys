#include "solve.h"
#include <cuda_runtime.h>
#include <algorithm>

#define FULL_MASK 0xffffffffu
constexpr int THREADS_PER_WARP = 32;

__global__ void gpu_dwconv2d(
    const float* __restrict__ x,
    const float* __restrict__ k,
    float* __restrict__ y,
    int N, int C, int H, int W,
    int KH, int KW,
    int pad_h, int pad_w,
    int stride_h, int stride_w,
    int OH, int OW)
{
    size_t idx = (size_t)blockIdx.x * blockDim.x + threadIdx.x;
    size_t stride = (size_t)blockDim.x * gridDim.x;
    // each thread processes 4 horizontal pixels, vector sets = total elements / 4.
    size_t vector_sets = ((size_t)N * C * OH * ((OW + 3) / 4));         // ceil (OW/4)

    for (; idx < vector_sets; idx += stride) 
    {
        // Decode index
        size_t temp = idx;
        int ow_block = (int)(temp % ((OW + 3) / 4)); temp /= ((OW + 3) / 4);
        int oh = (int)(temp % OH); 
        temp /= OH;

        int c = (int)(temp % C); 
        int n = (int)(temp / C);

        int ow_start = ow_block * 4;

        // set pointer to specific kernel for channel c
        const float* k_c = k + c * (KH * KW);

        // set pointer to input channel for batch n and channel c
        const float* x_nc = x + (size_t)((n * C + c)) * (H * W);

        // top left cornerd of the window
        int h_in_base = oh * stride_h - pad_h;
        int w_in_base = ow_start * stride_w - pad_w;

        // accumulators for 4 pixels
        float sum0 = 0.0f, sum1 = 0.0f, sum2 = 0.0f, sum3 = 0.0f;

        // check bounds for the 4 pixels
        bool valid0 = (ow_start < OW);
        bool valid1 = (ow_start + 1 < OW);
        bool valid2 = (ow_start + 2 < OW);
        bool valid3 = (ow_start + 3 < OW);

        for (int kh = 0; kh < KH; ++kh) 
        {
            int h_in = h_in_base + kh;
            
            if (h_in >= 0 && h_in < H) 
            {
                const float* x_row = x_nc + h_in * W;
                const float* k_row = k_c + kh * KW;

                for (int kw = 0; kw < KW; ++kw)
                {
                    float weight = k_row[kw]; // Load weight once

                    int w_in_0 = w_in_base + kw;

                    // Calculate positions for neighbors based on stride
                    int w_in_1 = w_in_0 + stride_w; 
                    int w_in_2 = w_in_1 + stride_w;
                    int w_in_3 = w_in_2 + stride_w;

                    if (valid0 && w_in_0 >= 0 && w_in_0 < W) sum0 += x_row[w_in_0] * weight;
                    if (valid1 && w_in_1 >= 0 && w_in_1 < W) sum1 += x_row[w_in_1] * weight;
                    if (valid2 && w_in_2 >= 0 && w_in_2 < W) sum2 += x_row[w_in_2] * weight;
                    if (valid3 && w_in_3 >= 0 && w_in_3 < W) sum3 += x_row[w_in_3] * weight;
                }
            }
        }

        // Write outputs
        size_t output_offset = ((size_t)n * C * OH * OW) + ((size_t)c * OH * OW) + ((size_t)oh * OW) + ow_start;
        if (valid0) y[output_offset + 0] = sum0;
        if (valid1) y[output_offset + 1] = sum1;
        if (valid2) y[output_offset + 2] = sum2;
        if (valid3) y[output_offset + 3] = sum3;
    }
}

void solve(const float* input,      // [N,C,H,W] 
           const float* kernel,     // [C,1,KH,KW] flattened as [C*KH*KW]
           float* output,           // [N,C,OH,OW]
           int N, int C, int H, int W, // input shape: batch, channel, height, weight
           int KH, int KW, // kernel height and weight
           int pad_h, int pad_w,    // kernel padding
           int stride_h, int stride_w)  // kernel stride
{
    if (N <= 0 || C <= 0 || H <= 0 || W <= 0 || KH <= 0 || KW <= 0) return;

    int OH = (H + 2 * pad_h - KH) / stride_h + 1;
    int OW = (W + 2 * pad_w - KW) / stride_w + 1;
    if (OH <= 0 || OW <= 0) return;

    int threads = 256;

    // Divide total work items by 4 since each thread does 4 pixels
    size_t total_vector_sets = (size_t)N * C * OH * ((OW + 3) / 4);
    
    size_t blocks_required = (total_vector_sets + threads - 1) / threads;
    int blocks = (int)(std::min(blocks_required, (size_t)(65535 * 4)));

    gpu_dwconv2d<<<blocks, threads>>>(
        input, kernel, output,
        N, C, H, W, KH, KW,
        pad_h, pad_w, stride_h, stride_w,
        OH, OW);
    
    cudaDeviceSynchronize();
}