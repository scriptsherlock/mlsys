#include "solve.h"
#include <cuda_runtime.h>
#include <algorithm> // For std::max, std::min

#define FULL_MASK 0xffffffffu
constexpr int THREADS_PER_WARP = 32;

__inline__ __device__ float warp_reduction_sum(float thread_value) 
{
    // manual warp as the size is set to 32.
    thread_value += __shfl_down_sync(FULL_MASK, thread_value, 16 );
    thread_value += __shfl_down_sync(FULL_MASK, thread_value, 8 );
    thread_value += __shfl_down_sync(FULL_MASK, thread_value, 4 );
    thread_value += __shfl_down_sync(FULL_MASK, thread_value, 2 );
    thread_value += __shfl_down_sync(FULL_MASK, thread_value, 1 );

    return thread_value;

}

__inline__ __device__ void block_reduction_sum(float& partial_sum) 
{
    // Collects partial sums from warps and does a block reduction
    __shared__ float warp_sum[32];

    int thread_position = threadIdx.x % THREADS_PER_WARP;
    int thread_warp_id  = threadIdx.x / THREADS_PER_WARP;
    partial_sum = warp_reduction_sum(partial_sum);
    if (thread_position == 0) 
    { 
        warp_sum[thread_warp_id] = partial_sum; 
    }
    __syncthreads();

    if (thread_warp_id == 0) 
    {
        partial_sum = (threadIdx.x < (blockDim.x / THREADS_PER_WARP)) ? warp_sum[thread_position] : 0.0f;

        partial_sum = warp_reduction_sum(partial_sum);

    }
}

__global__ __launch_bounds__(256) 
void fused_shared_mem(
    //calculates mean and variance in a single pass
    const float* __restrict__ x,
    const float* __restrict__ gamma,
    const float* __restrict__ beta,
    float* __restrict__ y,
    int N, int C, int spatial, float eps)
{
    extern __shared__ float channel_data[]; // Holds entire channel
    // Separate shared mem for broadcast to avoid overwriting data
    __shared__ float s_mean;
    __shared__ float s_scale;
    __shared__ float s_shift;

    int c = blockIdx.x; 
    if (c >= C) return;

    size_t stride_n = (size_t)C * spatial;
    size_t stride_c = (size_t)spatial;
    
    float local_sum = 0.0f;
    float local_sq_diff = 0.0f;
    
    // To load 4 elements from H*W at once, check if it can be vectorised.
    bool check_vectorise = ((size_t)x % 16 == 0) && (spatial % 4 == 0);
    
    // Calculate mean
    if (check_vectorise) {
        int vector_size = spatial / 4;
        for (int n = 0; n < N; ++n) 
        {
            size_t base = (size_t)n * stride_n + (size_t)c * stride_c;
            const float4* x4 = reinterpret_cast<const float4*>(x + base);
            
            int i = threadIdx.x;
            while (i < vector_size) 
            {
                float4 v = x4[i];
                int idx = n * spatial + i * 4;

                // Unpack the elements as components of vectors.
                channel_data[idx+0] = v.x; channel_data[idx+1] = v.y; channel_data[idx+2] = v.z; channel_data[idx+3] = v.w;
                
                local_sum += v.x + v.y + v.z + v.w;
                i += blockDim.x;
            }
        }

    } 
    else 
    {
        for (int n = 0; n < N; ++n) 
        {
            size_t base = (size_t)n * stride_n + (size_t)c * stride_c;
            for (int i = threadIdx.x; i < spatial; i += blockDim.x) 
            {
                float v = x[base + i];
                channel_data[n * spatial + i] = v;
                local_sum += v;
            }
        }
    }

    // Stats
    block_reduction_sum(local_sum);

    if (threadIdx.x == 0) 
    {
        float count = (float)(N * spatial);
        s_mean = local_sum / count;
    }
    
    __syncthreads(); 

    int total_elements = N * spatial;
    float mean_val = s_mean;

    for (int i = threadIdx.x; i < total_elements; i += blockDim.x) 
    {
        // read data from the cache (channel_data)
        float diff = channel_data[i] - mean_val;
        local_sq_diff += diff * diff; // Accumulate (x - mean)^2
    }

    block_reduction_sum(local_sq_diff);


    if (threadIdx.x == 0) 
    {
        float var = local_sq_diff / (float)total_elements;
        float invstd = rsqrtf(max(var, 0.0f) + eps);
        
        // write to dedicated shared variables
        s_scale = gamma[c] * invstd;
        s_shift = beta[c] - (mean_val * s_scale);
    }

    __syncthreads(); 
    
    // read from dedicated shared variables
    float scale = s_scale;
    float shift = s_shift;

    // normalise
    check_vectorise = ((size_t)y % 16 == 0) && (spatial % 4 == 0);

    if (check_vectorise) 
    {
        int vector_size = spatial / 4;
        for (int n = 0; n < N; ++n) 
        {
            size_t base = (size_t)n * stride_n + (size_t)c * stride_c;
            float4* y4 = reinterpret_cast<float4*>(y + base);

            int i = threadIdx.x;
            while (i < vector_size) 
            {
                int idx = n * spatial + i * 4;
                float4 r;
                r.x = channel_data[idx+0]; r.y = channel_data[idx+1]; r.z = channel_data[idx+2]; r.w = channel_data[idx+3];
                
                r.x = r.x * scale + shift;
                r.y = r.y * scale + shift;
                r.z = r.z * scale + shift;
                r.w = r.w * scale + shift;
                
                y4[i] = r;
                i += blockDim.x;
            }
        }
    } 
    else 
    {
        for (int n = 0; n < N; ++n) 
        {
            size_t base = (size_t)n * stride_n + (size_t)c * stride_c;
            for (int i = threadIdx.x; i < spatial; i += blockDim.x) 
            {
                y[base + i] = channel_data[n * spatial + i] * scale + shift;
            }
        }
    }
}

// Calculate Sum
__global__ void global_mem_compute_sum(
    const float* __restrict__ x,
    int N, int C, int spatial,
    float* __restrict__ global_sum)
{
    int c = blockIdx.x;
    int bgroup = blockIdx.y;
    int blocks_per_channel = gridDim.y;
    if (c >= C) return;

    size_t stride_n = (size_t)C * spatial;
    size_t stride_c = (size_t)spatial;
    
    float local_sum = 0.0f;

    if (spatial % 4 == 0 && (size_t)x % 16 == 0) 
    {
        int vector_size = spatial / 4;
        for (int n = 0; n < N; ++n) 
        {
            size_t base = (size_t)n * stride_n + (size_t)c * stride_c;
            const float4* x4 = reinterpret_cast<const float4*>(x + base);
            
            int idx = bgroup * blockDim.x + threadIdx.x;
            int step = blockDim.x * blocks_per_channel;

            // Unroll 8 vectors at once (memory coalescing) and compute sum
            while (idx + 7 * step < vector_size) {
                #pragma unroll
                for (int u = 0; u < 8; ++u) 
                {
                    float4 v = x4[idx + u * step];
                    local_sum += v.x + v.y + v.z + v.w;
                }
                idx += 8 * step;
            }

            for (; idx < vector_size; idx += step)
            {
                float4 v = x4[idx];
                local_sum += v.x + v.y + v.z + v.w;
            }
        }
    } 
    else 
    {
        for (int n = 0; n < N; ++n) {
            size_t base = (size_t)n * stride_n + (size_t)c * stride_c;
            for (int i = bgroup * blockDim.x + threadIdx.x; i < spatial; i += blockDim.x * blocks_per_channel) 
            {
                float v = x[base + i];
                local_sum += v;
            }
        }
    }
    
    block_reduction_sum(local_sum);
    if (threadIdx.x == 0) {
        atomicAdd(&global_sum[c], local_sum);
    }
}

// Calculate Sum of Squared Differences (x - mean)^2
__global__ void global_mem_compute_mean(
    const float* __restrict__ x,
    int N, int C, int spatial,
    const float* __restrict__ global_sum,
    float* __restrict__ global_sq_diff)
{
    int c = blockIdx.x;
    int bgroup = blockIdx.y;
    int blocks_per_channel = gridDim.y;
    if (c >= C) return;

    // Calculate mean
    float count = (float)(N * spatial);
    float mean = global_sum[c] / count;

    size_t stride_n = (size_t)C * spatial;
    size_t stride_c = (size_t)spatial;
    
    float local_sq_diff = 0.0f;

    if (spatial % 4 == 0 && (size_t)x % 16 == 0) {
        int vector_size = spatial / 4;
        for (int n = 0; n < N; ++n) 
        {
            size_t base = (size_t)n * stride_n + (size_t)c * stride_c;
            const float4* x4 = reinterpret_cast<const float4*>(x + base);
            
            int idx = bgroup * blockDim.x + threadIdx.x;
            int step = blockDim.x * blocks_per_channel;

            for (; idx < vector_size; idx += step) 
            {
                float4 v = x4[idx];
                float d1 = v.x - mean;
                float d2 = v.y - mean;
                float d3 = v.z - mean;
                float d4 = v.w - mean;
                local_sq_diff += d1*d1 + d2*d2 + d3*d3 + d4*d4;
            }
        }
    } 
    else 
    {
        for (int n = 0; n < N; ++n) 
        {
            size_t base = (size_t)n * stride_n + (size_t)c * stride_c;
            for (int i = bgroup * blockDim.x + threadIdx.x; i < spatial; i += blockDim.x * blocks_per_channel) 
            {
                float v = x[base + i];
                float diff = v - mean;
                local_sq_diff += diff * diff;
            }
        }
    }

    block_reduction_sum(local_sq_diff);
    if (threadIdx.x == 0) 
    {
        atomicAdd(&global_sq_diff[c], local_sq_diff);
    }
}

__global__ void gpu_bn_inference_nchw(
    const float* __restrict__ x,
    const float* __restrict__ sum,
    const float* __restrict__ sq_diff,
    const float* __restrict__ gamma,
    const float* __restrict__ beta,
    float* __restrict__ y,
    int N, int C, int spatial, float eps)
{
    int c = blockIdx.x;
    int bgroup = blockIdx.y;
    int blocks_per_channel = gridDim.y;
    if (blocks_per_channel == 0) blocks_per_channel = 1;
    if (c >= C) return;

    float count = (float)(N * spatial);
    float s = sum[c];
    float sq = sq_diff[c];
    float mean = s / count;
    
    // Variance is sum((x-mean)^2) / N*H*W
    float var = sq / count;
    
    float invstd = rsqrtf(max(var, 0.0f) + eps);
    float g = gamma[c];
    float scale = invstd * g;
    float shift = beta[c] - (mean * scale);

    size_t stride_n = (size_t)C * spatial;
    size_t stride_c = (size_t)spatial;

    if (spatial % 4 == 0 && (size_t)x % 16 == 0 && (size_t)y % 16 == 0) {
        int vector_size = spatial / 4;
        for (int n = 0; n < N; ++n) {
            size_t base = (size_t)n * stride_n + (size_t)c * stride_c;
            const float4* x4 = reinterpret_cast<const float4*>(x + base);
            float4* y4 = reinterpret_cast<float4*>(y + base);
            
            int idx = bgroup * blockDim.x + threadIdx.x;
            int step = blockDim.x * blocks_per_channel;

            for (; idx < vector_size; idx += step) {
                float4 v = x4[idx];
                v.x = v.x * scale + shift; v.y = v.y * scale + shift;
                v.z = v.z * scale + shift; v.w = v.w * scale + shift;
                y4[idx] = v;
            }
        }
    } 
    else 
    {
        for (int n = 0; n < N; ++n) 
        {
            size_t base = (size_t)n * stride_n + (size_t)c * stride_c;
            for (int i = bgroup * blockDim.x + threadIdx.x; i < spatial; i += blockDim.x * blocks_per_channel) 
            {
                y[base + i] = x[base + i] * scale + shift;
            }
        }
    }
}

void solve(const float* input, const float* gamma, const float* beta, float* output, 
           int N, int C, int H, int W, float eps)
{
    if (N <= 0 || C <= 0 || H <= 0 || W <= 0) return;

    int spatial = H * W;
    size_t channel_bytes = (size_t)N * spatial * sizeof(float);
    
    // Allocate shared memory for caching the data to allow for fast computation
    // if N*H*W is less than or equal to 96KB, use shared memory path.
    
    bool use_shared_memory = (channel_bytes <= 98304); 
    if (use_shared_memory) 
    {
        cudaFuncSetAttribute(fused_shared_mem, cudaFuncAttributeMaxDynamicSharedMemorySize, 98304);
        dim3 grid(C, 1, 1);
        dim3 block(256, 1, 1);
        fused_shared_mem<<<grid, block, channel_bytes>>>(input, gamma, beta, output, N, C, spatial, eps);
    } 
    else 
    {
        float *d_sum, *d_sq_diff;
        cudaMalloc(&d_sum, C * sizeof(float));
        cudaMalloc(&d_sq_diff, C * sizeof(float));
        cudaMemset(d_sum, 0, C * sizeof(float));
        cudaMemset(d_sq_diff, 0, C * sizeof(float));

        int threads = 256;
        int total_elements_per_channel = N * spatial;
        int vec_elements = (total_elements_per_channel + 3) / 4;
        int blocks_needed = (vec_elements + threads - 1) / threads;
        
        int blocks_per_channel = std::min(64, std::max(1, 4096 / C));
        blocks_per_channel = std::min(blocks_per_channel, blocks_needed);

        dim3 grid_stats(C, blocks_per_channel, 1);
        
        // Calculate sum of elements for mean
        global_mem_compute_sum<<<grid_stats, threads>>>(input, N, C, spatial, d_sum);

        // Calculate squared Diff (x-mean)^2 for variance
        global_mem_compute_mean<<<grid_stats, threads>>>(input, N, C, spatial, d_sum, d_sq_diff);

        // Normalise
        gpu_bn_inference_nchw<<<grid_stats, threads>>>(input, d_sum, d_sq_diff, gamma, beta, output, N, C, spatial, eps);

        cudaFree(d_sum); cudaFree(d_sq_diff);
    }
    cudaDeviceSynchronize();
}